import os
import numpy as np
import pandas as pd
import rasterio
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import joblib

# Define paths
img_path = r'D:\Coding_class\Final_Exam\Code-RS1\Multispectral_Image.tif'
train_tif_path = r'D:\Coding_class\Final_Exam\Code-RS1\ground_truth_tif.tif'
output_dir = r"C:\Users\HUYHOA-REMOTESENSING\Documents"

# Create output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

# Open the image
img = rasterio.open(img_path)
img_data = img.read()
bands, rows, cols = img_data.shape

# Select RGB bands and create an RGB composite
R_band = img_data[3]
G_band = img_data[2]
B_band = img_data[1]
rgb_img = np.dstack((R_band, G_band, B_band))
rgb_img_normalized = rgb_img / rgb_img.max()

# Plot the RGB composite image
plt.figure(figsize=(10, 8))
plt.title("Hyperspectral Image Composite (R: 60, G: 37, B: 15)")
plt.imshow(rgb_img_normalized)
plt.axis('off')
plt.show()

# Load the training data from a .tif file
train_dataset = rasterio.open(train_tif_path)
train_data = train_dataset.read(1)

# Plot training data over the RGB composite of the image
plt.figure(figsize=(10, 8))
plt.title("Hyperspectral Image with Training Data Overlay")
plt.imshow(rgb_img_normalized)
plt.imshow(train_data, alpha=0.5, cmap='jet')
plt.axis('off')
plt.show()

# Select specific bands for training
selected_bands_indices = [0,1,2,3,4,5,6,7,8,9,10]
selected_bands_data = img_data[selected_bands_indices, :, :]
selected_bands_reshaped = selected_bands_data.reshape(len(selected_bands_indices), -1).T

# Flatten training data to match pixel count
train_data_flat = train_data.flatten()

# Exclude class 0 from the training data
valid_indices = train_data_flat != 0
X_all = selected_bands_reshaped[valid_indices]
y_all = train_data_flat[valid_indices]

# Convert to DataFrame for consistency
dfAll = pd.DataFrame(X_all, columns=[f'Band{idx+1}' for idx in selected_bands_indices])
dfAll['class'] = y_all
dfAll.dropna(inplace=True)

# Sampling data for model training
nsamples = 200000
dfAll_sampled = dfAll.sample(n=nsamples, random_state=42)

# Features (X) and labels (y)
X = dfAll_sampled.drop('class', axis=1)
y = dfAll_sampled['class']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train Random Forest model with specified parameters
model = RandomForestClassifier(n_estimators=300, max_features=2, random_state=42)
model.fit(X_train, y_train)

# Model evaluation
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))
conf_mat = confusion_matrix(y_test, y_pred)
print(conf_mat)

# Feature importance
importances = model.feature_importances_
indices = np.argsort(importances)[::-1]

# Plot feature importance
plt.figure(figsize=(12, 6))
plt.title("Feature Importance")
plt.bar(range(X_train.shape[1]), importances[indices])
plt.xticks(range(X_train.shape[1]), X.columns[indices], rotation=90)
plt.show()

# Save the trained model
model_output_path = os.path.join(output_dir, "rf_model.pkl")
joblib.dump(model, model_output_path)
print(f"Trained model saved to {model_output_path}")

# Predict on the entire image using selected bands
selected_bands_full_reshaped = pd.DataFrame(selected_bands_data.reshape(len(selected_bands_indices), -1).T, columns=X.columns)
preds = model.predict(selected_bands_full_reshaped)

# Reshape predictions back to the original image shape
preds_img = preds.reshape((rows, cols))

# Plot the classification result
plt.figure(figsize=(10, 8))
plt.title("Classification Result")
plt.imshow(preds_img, cmap='jet')
plt.colorbar()
plt.axis('off')
plt.show()

# Save the prediction result as a new .tif file
prediction_output_path = os.path.join(output_dir, "RF_Landsat2.tif")
with rasterio.open(
    prediction_output_path,
    'w',
    driver='GTiff',
    height=rows,
    width=cols,
    count=1,
    dtype=preds_img.dtype,
    crs=img.crs,
    transform=img.transform,
) as dst:
    dst.write(preds_img, 1)

print(f"Prediction saved to {prediction_output_path}")

# Function to calculate overall accuracy, kappa, user's accuracy, producer's accuracy, omission, and commission errors
def evaluate_classification(conf_mat, class_labels):
    overall_accuracy = np.trace(conf_mat) / np.sum(conf_mat)
    N = np.sum(conf_mat)
    po = np.trace(conf_mat) / N
    pe = np.sum(np.sum(conf_mat, axis=0) * np.sum(conf_mat, axis=1)) / (N * N)
    kappa = (po - pe) / (1 - pe)

    user_accuracy = np.diag(conf_mat) / np.sum(conf_mat, axis=0)
    producer_accuracy = np.diag(conf_mat) / np.sum(conf_mat, axis=1)
    commission_error = 1 - user_accuracy
    omission_error = 1 - producer_accuracy

    print("\nOverall Accuracy:", overall_accuracy)
    print("Kappa Coefficient:", kappa)
    print("\nClass-wise metrics:")

    metrics_df = pd.DataFrame({
        "Class": class_labels,
        "User's Accuracy": user_accuracy,
        "Producer's Accuracy": producer_accuracy,
        "Commission Error": commission_error,
        "Omission Error": omission_error
    })

    print(metrics_df)
    return overall_accuracy, kappa, metrics_df

# Define class labels
class_labels = ["Water", "Forest", "Urban", "Land Use", "Non-Classified"]

# Calculate and display accuracy metrics
evaluate_classification(conf_mat, class_labels)
