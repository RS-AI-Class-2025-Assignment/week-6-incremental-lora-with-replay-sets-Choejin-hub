import torch
import torchvision.transforms as T
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import median_filter


# Load the DeepLabV3+ model from PyTorch Hub
def load_deeplabv3_plus_model():
    print("Loading DeepLabV3+ model...")
    model = torch.hub.load('pytorch/vision:v0.13.0', 'deeplabv3_resnet101', weights="DEFAULT")
    model.eval()  # Set the model to evaluation mode
    return model


# Preprocess the input image
def preprocess_image(image_path, target_size=(513, 513)):
    input_image = Image.open(image_path).convert("RGB")  # Load and convert to RGB
    preprocess = T.Compose([
        T.Resize(target_size),  # Resize to model's input size
        T.ToTensor(),  # Convert to Tensor
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),  # Normalize
    ])
    input_tensor = preprocess(input_image).unsqueeze(0)  # Add batch dimension
    return input_image, input_tensor


# Resize segmentation map back to original image size
def resize_segmentation(segmentation, original_size):
    segmentation_resized = T.functional.resize(
        segmentation.unsqueeze(0), original_size, interpolation=T.InterpolationMode.NEAREST
    )
    return segmentation_resized.squeeze(0).numpy()


# Apply post-processing with a median filter to refine results
def apply_median_filter(segmentation, size=5):
    smoothed_segmentation = median_filter(segmentation, size=size)
    return smoothed_segmentation


# Decode segmentation map into a color image
def decode_segmentation(segmentation, num_classes=21):
    # Define a colormap for visualization
    colormap = np.random.randint(0, 255, size=(num_classes, 3), dtype=np.uint8)
    colormap[0] = [0, 0, 0]  # Background color as black

    class_indices = segmentation.astype(int)  # Ensure segmentation is integer-based
    color_image = np.zeros((segmentation.shape[0], segmentation.shape[1], 3), dtype=np.uint8)

    for class_id in range(num_classes):
        color_image[class_indices == class_id] = colormap[class_id]

    return color_image


# Evaluate segmentation performance with mIoU and pixel accuracy
def evaluate_segmentation(segmentation, ground_truth):
    intersection = np.logical_and(segmentation == ground_truth, segmentation > 0)
    union = np.logical_or(segmentation > 0, ground_truth > 0)

    iou = np.sum(intersection) / np.sum(union) if np.sum(union) > 0 else 0
    pixel_accuracy = np.sum(segmentation == ground_truth) / ground_truth.size

    return iou, pixel_accuracy


# Main function
if __name__ == "__main__":
    # File paths
    image_path = r"D:\Coding_class\W9-1\cat-dog-625x375.jpg"
    ground_truth_path = None  # Optional path to ground truth for evaluation

    # Load the model and preprocess the input image
    model = load_deeplabv3_plus_model()
    original_image, input_tensor = preprocess_image(image_path)

    # Perform segmentation
    with torch.no_grad():
        output = model(input_tensor)["out"]

    # Find the most likely class for each pixel
    predicted_classes = torch.argmax(output.squeeze(), dim=0).cpu()

    # Resize the segmentation map back to the original image size
    segmentation_resized = resize_segmentation(predicted_classes, original_image.size[::-1])

    # Apply median filter for post-processing
    segmentation_smoothed = apply_median_filter(segmentation_resized, size=5)

    # Decode the smoothed segmentation map into a color image
    segmentation_colored = decode_segmentation(segmentation_smoothed)

    # Optional evaluation if ground truth is provided
    if ground_truth_path:
        ground_truth_image = Image.open(ground_truth_path).convert("L")  # Load ground truth as grayscale
        ground_truth = np.array(ground_truth_image)
        iou, pixel_accuracy = evaluate_segmentation(segmentation_smoothed, ground_truth)
        print(f"Mean IoU: {iou:.4f}, Pixel Accuracy: {pixel_accuracy:.4f}")

    # Display the original image and the segmentation result
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.title("Original Image")
    plt.imshow(original_image)

    plt.subplot(1, 2, 2)
    plt.title("Segmented Image")
    plt.imshow(segmentation_colored)
    plt.axis("off")
    plt.show()
