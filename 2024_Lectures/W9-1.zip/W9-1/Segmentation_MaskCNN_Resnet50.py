import torch
from PIL import Image
import torchvision.transforms as T
import matplotlib.pyplot as plt
import numpy as np
import random
import cv2  # OpenCV for image saving and resizing
from torchvision.ops import nms

# Debugging utility
def debug_dimensions(label, array):
    if isinstance(array, torch.Tensor):
        print(f"{label} - Tensor Shape: {list(array.shape)}")
    elif isinstance(array, np.ndarray):
        print(f"{label} - Array Shape: {array.shape}")
    else:
        print(f"{label} - Unknown Type")

# Resize image for visualization
def force_downsampling(image, max_size=800):
    """
    Forces downsampling of large images to fit within max_size dimensions.

    Args:
        image (np.array): Input image (H, W, C).
        max_size (int): Maximum dimension for resizing.

    Returns:
        np.array: Resized image.
    """
    h, w = image.shape[:2]
    if max(h, w) > max_size:
        scale = max_size / max(h, w)
        new_size = (int(w * scale), int(h * scale))
        print(f"Downsampling to {new_size} for rendering...")
        image_resized = cv2.resize(image, new_size, interpolation=cv2.INTER_LINEAR)
        return image_resized
    return image

# Apply Non-Maximum Suppression (NMS)
def apply_nms(masks, boxes, labels, scores, iou_threshold=0.5, score_threshold=0.5):
    """
    Applies Non-Maximum Suppression (NMS) to remove redundant predictions.

    Args:
        masks (torch.Tensor): Segmentation masks (N, H, W).
        boxes (torch.Tensor): Bounding boxes (N, 4).
        labels (torch.Tensor): Class labels (N).
        scores (torch.Tensor): Confidence scores (N).
        iou_threshold (float): IoU threshold for NMS.
        score_threshold (float): Minimum confidence score threshold.

    Returns:
        Tuple[torch.Tensor]: Filtered masks, boxes, labels, scores.
    """
    # Filter by score threshold
    valid_indices = scores > score_threshold
    masks = masks[valid_indices]
    boxes = boxes[valid_indices]
    labels = labels[valid_indices]
    scores = scores[valid_indices]

    # Apply NMS
    keep_indices = nms(boxes, scores, iou_threshold)
    return masks[keep_indices], boxes[keep_indices], labels[keep_indices], scores[keep_indices]

# Visualize instance segmentation
def visualize_instance_segmentation(image, masks, labels, scores, boxes=None, threshold=0.5, max_size=800, output_path="output_segmentation.png"):
    """
    Visualizes instance segmentation results by overlaying masks and optionally bounding boxes.

    Args:
        image (PIL.Image): Original input image.
        masks (torch.Tensor): Segmentation masks for objects.
        labels (torch.Tensor): Class labels for objects.
        scores (torch.Tensor): Confidence scores for objects.
        boxes (torch.Tensor): Optional bounding boxes for objects.
        threshold (float): Confidence threshold for displaying masks.
        max_size (int): Maximum size for the visualization image.
        output_path (str): Path to save the output visualization.
    """
    print("Visualizing instance segmentation results...")
    image_np = np.array(image)
    overlay = image_np.copy()

    for i in range(len(masks)):
        mask = masks[i].squeeze().numpy()
        color = [random.randint(0, 255) for _ in range(3)]
        overlay[mask] = overlay[mask] * 0.5 + np.array(color) * 0.5

        label = labels[i].item()
        class_name = COCO_INSTANCE_CATEGORY_NAMES[label]
        y, x = np.where(mask)
        y, x = int(np.median(y)), int(np.median(x))
        cv2.putText(overlay, class_name, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

        # Optionally draw bounding boxes
        if boxes is not None:
            box = boxes[i].numpy().astype(int)
            cv2.rectangle(overlay, (box[0], box[1]), (box[2], box[3]), (255, 255, 255), 2)

    # Debugging dimensions before resizing
    debug_dimensions("Overlay Image Before Resizing", overlay)

    # Force resize overlay before rendering
    overlay_resized = force_downsampling(overlay, max_size)

    # Debugging dimensions after resizing
    debug_dimensions("Overlay Image After Resizing", overlay_resized)

    # Save the output to avoid Matplotlib rendering issues
    cv2.imwrite(output_path, cv2.cvtColor(overlay_resized, cv2.COLOR_RGB2BGR))
    print(f"Saved visualization to {output_path}")

    # Reload the saved image and display with Matplotlib
    saved_image = Image.open(output_path)
    saved_image.show()  # Displays the image using the default image viewer

# COCO class names
COCO_INSTANCE_CATEGORY_NAMES = ['__background__', 'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus',
                                 'train', 'truck', 'boat', 'traffic light', 'fire hydrant', 'N/A', 'stop sign',
                                 'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow',
                                 'elephant', 'bear', 'zebra', 'giraffe', 'N/A', 'backpack', 'umbrella',
                                 'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball',
                                 'kite', 'baseball bat', 'baseball glove', 'skateboard', 'surfboard',
                                 'tennis racket', 'bottle', 'wine glass', 'cup', 'fork', 'knife', 'spoon',
                                 'bowl', 'banana', 'apple', 'sandwich', 'orange', 'broccoli', 'carrot',
                                 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch', 'potted plant',
                                 'bed', 'mirror', 'dining table', 'window', 'desk', 'toilet', 'door', 'tv',
                                 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone', 'microwave', 'oven',
                                 'toaster', 'sink', 'refrigerator', 'blender', 'book', 'clock', 'vase',
                                 'scissors', 'teddy bear', 'hair drier', 'toothbrush']

# Main function
if __name__ == "__main__":
    # Input image path
    image_path = r"C:\Users\HUYHOA-REMOTESENSING\Desktop\quiz\cat-dog-625x375.jpg"

    # Load model and preprocess image
    from torchvision.models.detection import maskrcnn_resnet50_fpn
    model = maskrcnn_resnet50_fpn(pretrained=True)
    model.eval()
    original_image = Image.open(image_path).convert("RGB")
    input_tensor = T.Compose([T.ToTensor()])(original_image).unsqueeze(0)

    with torch.no_grad():
        predictions = model(input_tensor)[0]

    # Extract outputs
    masks = predictions['masks'] > 0.5  # Threshold masks
    boxes = predictions['boxes']        # Bounding boxes
    labels = predictions['labels']      # Class labels
    scores = predictions['scores']      # Confidence scores

    debug_dimensions("Masks", masks)

    # Apply NMS to suppress duplicates
    masks, boxes, labels, scores = apply_nms(masks, boxes, labels, scores, iou_threshold=0.5, score_threshold=0.5)

    # Visualize results
    visualize_instance_segmentation(original_image, masks, labels, scores, boxes)
