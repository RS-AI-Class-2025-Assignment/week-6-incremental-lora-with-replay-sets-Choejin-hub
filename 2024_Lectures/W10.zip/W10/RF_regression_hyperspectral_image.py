import rasterio
import geopandas as gpd
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn import metrics
import matplotlib.pyplot as plt
from rasterio.features import rasterize
from sklearn.preprocessing import StandardScaler

# Paths to data
hyperspectral_data_path = r'D:\Kyeongeun_data\A2_test_tif2\A2_projection2.tif'
shapefile_path = r'D:\Kyeongeun_data\test2\A2_content_3.shp'

# Function to read GeoTIFF data
def read_geotiff(path):
    with rasterio.open(path) as src:
        data = src.read()  # Read all bands
        profile = src.profile
        transform = src.transform  # Affine transform
    return data, profile, transform

# Function to align shapefile points with raster grid
def align_shapefile_with_raster(shapefile, transform, raster_shape):
    rasterized = rasterize(
        [(geom, 1) for geom in shapefile.geometry],
        transform=transform,
        out_shape=raster_shape,
        fill=0,
        dtype='uint8'
    )
    return rasterized

# Function to plot hyperspectral data and overlay shapefile points
def plot_hyperspectral_and_shapefile(hyperspectral_data, rasterized_shapefile, bands_rgb=(60, 36, 18)):
    num_bands = hyperspectral_data.shape[0]
    if any(band > num_bands or band < 1 for band in bands_rgb):
        raise ValueError(f"Invalid band indices: {bands_rgb}. The hyperspectral data has {num_bands} bands.")
    
    def normalize_band(band):
        return np.clip((band - band.min()) / (band.max() - band.min()) * 255, 0, 255).astype(np.uint8)
    
    r_band = normalize_band(hyperspectral_data[bands_rgb[0] - 1])
    g_band = normalize_band(hyperspectral_data[bands_rgb[1] - 1])
    b_band = normalize_band(hyperspectral_data[bands_rgb[2] - 1])
    
    rgb_image = np.dstack((r_band, g_band, b_band))
    
    plt.figure(figsize=(12, 10))
    plt.imshow(rgb_image)
    plt.imshow(rasterized_shapefile, alpha=0.5, cmap='Reds')
    plt.title('Hyperspectral Image with Shapefile Overlay')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.show()

# Step 1: Load hyperspectral data and shapefile
hyperspectral_data, profile, transform = read_geotiff(hyperspectral_data_path)
shapefile = gpd.read_file(shapefile_path)

# Align shapefile points with raster grid
rows, cols = profile['height'], profile['width']
rasterized_shapefile = align_shapefile_with_raster(shapefile, transform, (rows, cols))

# Plot hyperspectral data with shapefile overlay
plot_hyperspectral_and_shapefile(hyperspectral_data, rasterized_shapefile)

# Step 2: Extract training data using "MEK" column
training_data = []
training_labels = []

for _, point in shapefile.iterrows():
    x, y = point.geometry.x, point.geometry.y
    col, row = ~transform * (x, y)  # Convert coordinates to pixel indices
    col, row = int(col), int(row)
    if 0 <= row < rows and 0 <= col < cols:
        pixel_reflectance = hyperspectral_data[:, row, col]
        chemical_content = point['EDA']
        training_data.append(pixel_reflectance)
        training_labels.append(chemical_content)

training_data = np.array(training_data)
training_labels = np.array(training_labels)

# Normalize features
scaler = StandardScaler()
training_data = scaler.fit_transform(training_data)

# Step 3: Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(training_data, training_labels, test_size=0.3, random_state=42)

# Step 4: Train Random Forest model with OOB score
rf_model = RandomForestRegressor(
    n_estimators=5000,
    criterion='squared_error',
    max_depth=25,
    max_features='sqrt',
    bootstrap=True,
    max_samples=0.9,
    oob_score=True,  # Enable Out-of-Bag error calculation
    random_state=42
)
rf_model.fit(X_train, y_train)

# Calculate OOB score
oob_score = rf_model.oob_score_
print(f"Out-of-Bag (OOB) Score: {oob_score}")

# Step 5: Evaluate model performance on test data
y_train_pred = rf_model.predict(X_train)
y_test_pred = rf_model.predict(X_test)

# Filter out background values (assume background is greater than 10000)
valid_indices = y_test < 10000
filtered_y_test = y_test[valid_indices]
filtered_y_test_pred = y_test_pred[valid_indices]

# Calculate metrics only for valid data
mae = metrics.mean_absolute_error(filtered_y_test, filtered_y_test_pred)
mse = metrics.mean_squared_error(filtered_y_test, filtered_y_test_pred)
rmse = np.sqrt(mse)
r2 = metrics.r2_score(filtered_y_test, filtered_y_test_pred)

# Calculate RMSE% based on range and mean
target_range = filtered_y_test.max() - filtered_y_test.min()
target_mean = filtered_y_test.mean()

rmse_percent_range = (rmse / target_range) * 100
rmse_percent_mean = (rmse / target_mean) * 100

# Print metrics
print(f"MAE: {mae}")
print(f"MSE: {mse}")
print(f"RMSE: {rmse}")
print(f"R² Score: {r2}")
print(f"RMSE% (Based on Range): {rmse_percent_range:.2f}%")
print(f"RMSE% (Based on Mean): {rmse_percent_mean:.2f}%")


# Step 6: Visualize training vs testing accuracy
plt.figure(figsize=(8, 6))
plt.bar(['Train R²', 'Test R²'], [train_r2, test_r2], color=['blue', 'orange'])
plt.title("Training vs Testing Accuracy")
plt.ylabel("R² Score")
plt.ylim(0, 1.1)
plt.show()

# Step 7: Predict for all pixels in hyperspectral image
pixels = hyperspectral_data.reshape(hyperspectral_data.shape[0], -1).T
pixels = scaler.transform(pixels)  # Normalize all pixels
predicted_values = rf_model.predict(pixels)
predicted_image = predicted_values.reshape(rows, cols)

# Step 8: Save and visualize predicted image
output_path = r'D:\Kyeongeun_data\Predicted_Chemical_Content_EDA.tif'
with rasterio.open(output_path, 'w', driver='GTiff', height=rows, width=cols, count=1, dtype='float32') as dst:
    dst.write(predicted_image.astype('float32'), 1)

# Visualize prediction output
plt.figure(figsize=(10, 8))
plt.imshow(predicted_image, cmap='viridis')
cbar = plt.colorbar()
cbar.set_label('Predicted Chemical Content', rotation=270, labelpad=15)
plt.title("Predicted Chemical Content")
plt.xlabel("Column")
plt.ylabel("Row")
plt.show()

print(f"Predicted chemical content image saved to {output_path}")
